This font is Commercial Use, Enjoy!

If you need Extended License or more contact us at:

pandekastudio@gmail.com

-----------------------------------------------------------------

Hello!

Here's the tutorial to upload/install : youtu.be/5MvAX8uDP6E

To access all the letters (heart, swash, connected letter)

   For windows : youtu.be/O3e6R3ayk9Q

   For mac : youtu.be/Y7esONryoCM

   In Canva : http://y2u.be/sjmQHQ5jhl8

   In Procreate : youtu.be/Tg3HL0O-OmM

   In Adobe : youtu.be/_CNCL1vC2Kw

Hope that can help, thank you for being so patient with me at this time and stay safe.

-----------------------------------------------------------------

More Information please contact me :

pandekastudio@gmail.com